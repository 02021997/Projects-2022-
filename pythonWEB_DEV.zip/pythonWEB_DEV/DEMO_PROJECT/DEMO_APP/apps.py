from django.apps import AppConfig


class DemoAppConfig(AppConfig):
    name = 'DEMO_APP'
